<?php $__env->startSection('content'); ?>

    <div id="central">
                <div id="login">
                    <div class="titulo">
                        Bienvenido
                    </div>
                    <form id="loginform" action="index" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="text" name="email" placeholder="Email" required>
                        <input type="password" name="password" placeholder="Contraseña" required>
                        
                        <button type="submit" title="Ingresar" name="Ingresar">Login</button>
                    </form>
                    <div class="pie-form">
                        <a href="index2">¿No tienes Cuenta? Registrate</a>
                    </div>
                </div>
                <div class="inferior">
                    <a href="#">Volver</a>
                </div>
            </div>


<style>
    .nav-link{
        cursor: not-allowed;
        pointer-events:none;
    }

#central {
    max-width: 320px;
    width: 100%;
}

.titulo {
    font-size: 250%;
    color:white;
    text-align: center;
    margin-bottom: 20px;
}

#login {
    width: 100%;
    padding: 60px 30px;
    background-color: #222529;
    
    -webkit-box-shadow: 0px 0px 5px 5px rgba(0,0,0,0.15);
    -moz-box-shadow: 0px 0px 5px 5px rgba(0,0,0,0.15);
    box-shadow: 0px 0px 5px 5px rgba(0,0,0,0.15);
    
    border-radius: 3px 3px 3px 3px;
    -moz-border-radius: 3px 3px 3px 3px;
    -webkit-border-radius: 3px 3px 3px 3px;
    
    box-sizing: border-box;
}

#login input {
    font-family: 'Overpass', sans-serif;
    font-size: 110%;
    color: #1b262c;
    
    display: block;
    width: 100%;
    height: 40px;
    
    margin-bottom: 10px;
    padding: 5px 5px 5px 10px;
    
    box-sizing: border-box;
    
    border: none;
    border-radius: 3px 3px 3px 3px;
    -moz-border-radius: 3px 3px 3px 3px;
    -webkit-border-radius: 3px 3px 3px 3px;
}

#login input::placeholder {
    font-family: 'Overpass', sans-serif;
    color: #606263;
}

#login button {
    font-family: 'Overpass', sans-serif;
    font-size: 110%;
    color:#1b262c;
    width: 100%;
    height: 40px;
    border: none;
    
    border-radius: 3px 3px 3px 3px;
    -moz-border-radius: 3px 3px 3px 3px;
    -webkit-border-radius: 3px 3px 3px 3px;
    
    background-color: #edca4c;
    
    margin-top: 10px;
}

#login button:hover {
    background-color: #ffc800;
    color:black;
}

.pie-form {
    font-size: 90%;
    text-align: center;    
    margin-top: 15px;
}

.pie-form a {
    display: block;
    text-decoration: none;
    color: white;
    margin-bottom: 3px;
}

.pie-form a:hover {
    color: #ffc800;
}

.inferior {
    margin-top: 10px;
    font-size: 90%;
    text-align: center;
}

.inferior a {
    display: block;
    text-decoration: none;
    color: white;
    margin-bottom: 3px;
}

.inferior a:hover {
    color: #ffc800;
}

    </style>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('reseñas.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laraveles/MyApp2/resources/views/reseñas/index.blade.php ENDPATH**/ ?>