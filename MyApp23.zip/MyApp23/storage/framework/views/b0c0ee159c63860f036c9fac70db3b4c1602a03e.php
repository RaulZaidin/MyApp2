<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <h1>Crear Reseña</h1>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content2'); ?>
<section class="page-section bg-light" id="portfolio">
            <div class="container">
                <div class="row">
                    <section class="page-section" id="contact">
            <div class="container">
                <form id="Form" action="store" enctype="multipart/form-data" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="row align-items-stretch mb-5">
                        <div class="col-md-6">
                            <div class="form-group">
                                <!-- Titulo input-->
                                <input class="form-control" id="titulo" name="titulo" type="text" placeholder="Titulo" required/>
                            </div>
                            <div class="form-group" style="margin-top:20px">
                               <select class="form-control" name="tipo" id="tipo">
                                    <option value="selecciona">Selecciona el tipo</option>
                                    <option value="musica">Musica</option>
                                    <option value="pelicula">Pelicula</option>
                                    <option value="libro">Libro</option>
                              </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group form-group-textarea mb-md-0">
                                <!-- Reseña input-->
                                <textarea style="height:95px" class="form-control" id="contReview" name="contReview" placeholder="Reseña"></textarea>
                            </div>
                        </div>
                        <div class="col-md-6" style="margin-top:20px">
                            <input type="file" name="file" id="file"/>
                        </div>
                    </div>
                    
                    <div class="text-center"><button class="btn btn-primary btn-xl text-uppercase" id="submitButton" type="submit">Crear Reseña</button></div>
                </form>
            </div>
        </section>

                </div>
            </div>
        </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('reseñas.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laraveles/MyApp23/resources/views/reseñas/create.blade.php ENDPATH**/ ?>