<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content2'); ?>
<section class="page-section bg-light" id="portfolio">
            <div class="container">
                <div class="text-center">
                    <h2 class="section-heading text-uppercase">Música</h2>
                    <h3 class="section-subheading text-muted">Ahora puedes ver todas la reviews sobre música</h3>
                </div>
                <div class="row">
                     <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $tipo = $review->tipo;
                        $tipo2 = 'musica';
                    ?>
                        <?php if($tipo == $tipo2): ?>
                        
                    <div class="col-lg-4 col-sm-6 mb-4">
                        <!-- Portfolio item 1-->
                        <div class="portfolio-item">
                            <a class="portfolio-link" data-bs-toggle="modal" href="<?php echo e(route('showReview', $review)); ?>">
                                <img class="img-fluid" src="storage/app/public/images/<?php echo e($review->images->file); ?>" alt="..." />
                            </a>
                            <div class="portfolio-caption">
                                <div class="portfolio-caption-heading"><?php echo e($review->titulo); ?></div>
                                <div class="portfolio-caption-subheading text-muted"><?php echo e($review->tipo); ?></div>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('reseñas.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laraveles/MyApp23/resources/views/reseñas/homeMusica.blade.php ENDPATH**/ ?>