<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <h1></h1>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content2'); ?>
<section class="page-section bg-light" id="portfolio">
            <div class="container">
                <div class="row">
                    <img style="height:500px" class="img-fluid" src="../storage/app/public/images/<?php echo e($review->images->file); ?>" alt="..." />
                    <h1 style="padding-top:30px" class="portfolio-caption-heading"><?php echo e($review->titulo); ?></h1>
                    <h3 class="portfolio-caption-subheading text-muted"><?php echo e($review->tipo); ?></h3>
                    <hr>
                    <p><?php echo e($review->contReview); ?></p>
                    <?php if($review->idusuario == $id): ?>
                    <div class="text-center">
                        <form style="display:inline-block" action="<?php echo e(route('edit', $review)); ?>" method="get">
                            <button class="btn btn-primary btn-xs text-uppercase" id="editButton" type="submit">Editar</button>
                        </form>
                        <form style="display:inline-block" action="<?php echo e(url('delete/'. $review->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-primary btn-xs text-uppercase" id="deleteButton" type="submit">Borrar</button>
                        </form>
                    </div>
                    <?php else: ?>
                    <h5 class="portfolio-caption-subheading text-muted"><?php echo e($review->users->name); ?></h5>
                    
                    <?php endif; ?>

                </div>
            </div>
        </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('reseñas.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laraveles/MyApp23/resources/views/reseñas/showReview.blade.php ENDPATH**/ ?>