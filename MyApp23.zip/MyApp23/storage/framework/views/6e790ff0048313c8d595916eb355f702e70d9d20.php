<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <h1></h1>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content2'); ?>
<section class="page-section bg-light" id="portfolio">
            <div class="container">
                <div class="row">
                    

                </div>
            </div>
        </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('reseñas.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laraveles/MyApp23/resources/views/reseñas/edit.blade.php ENDPATH**/ ?>