<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('reviews', function (Blueprint $table) {
            $table->id();
            $table->string('titulo', 80);
            $table->string('tipo', 20);
            $table->string('contReview', 200);
            $table->unsignedBigInteger('idusuario');
            $table->unsignedBigInteger('idimage');
            $table->foreign('idusuario')->references('id')->on('users');
            $table->foreign('idimage')->references('id')->on('images');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('reviews');
    }
};
