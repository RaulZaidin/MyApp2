<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\LoginRequest;
use Illuminate\Support\Facades\Auth;


class LoginController extends Controller
{
    //
    public function show(){
        return view('reseñas.index');
    }
    
    public function login(LoginRequest $request){
        // $credentials = [
        //     "email" => $request->email,
        //     "password" => $request->password
        //     ];
            
        //      if(Auth::attempt($credentials)){
                
        //         return redirect()->intented(route('home'));
        //      }else{
        //          return redirect('index');
        //      }
        $credentials = $request->getCredentials();
            if(Auth::validate($credentials)){//Si no existe el usuario
            return redirect()->to('index')->withErrors('auth.failed');
         }
             $user = Auth::getProvider()->retrieveByCredentials($credentials);
             Auth::login($user);
             return $this->authenticated($request, $user);
    }
    
    public function authenticated(Request $request, $user){
        return redirect('home');    
    }
}
