<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\LoginRequest;
use Illuminate\Support\Facades\Auth;
use App\Models\User;


class LoginController extends Controller
{
    //
    public function show(){
        return view('reseñas.index');
    }
    
    public function login(Request $request){            //LoginRequest $request
       $users = User::all();
      $credentials = request()->only('email', 'password');
       
      foreach($users as $user){
          if(($user->email) == ($request->email)){
              if(($user->password) == ($request->password)){
                //   return redirect('home');
                 $user = Auth::getProvider()->retrieveByCredentials($credentials);
                 Auth::login($user);
                 return $this->authenticated($request, $user);
              }
          }
          
      }
      return redirect()->to('index')->withErrors('auth.failed');
       
       
        // $credentials = $request->getCredentials();
        // if(Auth::validate($credentials)){//Si no existe el usuario
        //     return redirect()->to('index')->withErrors('auth.failed');
        //  }
        //  $user = Auth::getProvider()->retrieveByCredentials($credentials);
        //  Auth::login($user);
        //  return $this->authenticated($request, $user);
    }
    
    public function authenticated(Request $request, $user){
        return redirect('home');    
    }
}
