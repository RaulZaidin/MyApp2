<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\RegisterRequest; //Clase para validar reglas del registro
use App\Models\User;


class RegisterController extends Controller
{
    //
    public function show(){
        return view('index2');
    }
    
    public function register(RegisterRequest $request){
        $user = User::create($request->validated());
        
        // Mail::send('', $request, function($message) use ($request){
            
        // })
        return redirect('index');
    }
}
