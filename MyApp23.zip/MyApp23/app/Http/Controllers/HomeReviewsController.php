<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Review;
use App\Models\Image;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests\ReviewRequest;
use Carbon\Carbon;

class HomeReviewsController extends Controller
{
    //
    public function index(){
        $reviews = Review::all();
        $id = Auth::id();
        return view('reseñas.show',['activePosts'=> 'active','reviews' => $reviews, 'subTitle'=> 'Reviews - Index', 'id'=>$id]);
    }

    public function showMusica()
    {
        $reviews = Review::all();
        return view('reseñas.homeMusica',['activePosts'=> 'active','reviews' => $reviews, 'subTitle'=> 'Reviews - Index']);
    }
    public function showPelicula()
    {
        $reviews = Review::all();
        return view('reseñas.homePelicula',['activePosts'=> 'active','reviews' => $reviews, 'subTitle'=> 'Reviews - Index']);
    }
    public function showLibro()
    {
        $reviews = Review::all();
        return view('reseñas.homeLibro',['activePosts'=> 'active','reviews' => $reviews, 'subTitle'=> 'Reviews - Index']);
    }
    function create(){
        return view('reseñas.create');
    }
    
    function store(Request $request){
        if($archivo = $request->file('file')) {
            $nombre = $archivo->getClientOriginalName();
            $archivo->move('storage/app/public/images', $nombre);
             $upload = new Image();
            $upload->file = $nombre;
            $upload->save();
             
            
        }
        $review = new Review();
        $review->titulo=$request->titulo;
        $review->tipo=$request->tipo;
        $review->contReview=$request->contReview;
        $review->idusuario= Auth::id();
        $review->idimage = $upload->id;
        $review-> save();
        return redirect("home");
    }
    public function edit(Review $review){
        return view('reseñas.edit', ['review' => $review]);
    }
}
