<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\LogoutController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\RegisterController;
use App\Http\Controllers\HomeReviewsController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/index2', function () {
    return view('reseñas.index2');
});

Route::get('/',[LoginController::class, 'show']);

// Route::view('/', 'welcome');
// Route::view('login', 'login');
// Route::view('dashboard', 'dashboard');


Route::get('/home',[HomeController::class, 'index'])->name('home');

Route::get('/index',[LoginController::class, 'show']);

Route::post('/index2', [RegisterController::class,'register']);
Route::post('/index', [LoginController::class, 'login']);

Route::get('/logout',[LogoutController::class, 'logout'] );

Route::get('/homeMusica',[HomeReviewsController::class, 'showMusica'])->name('homeMusica');
Route::get('/homePelicula',[HomeReviewsController::class, 'showPelicula'])->name('homePelicula');
Route::get('/homeLibro',[HomeReviewsController::class, 'showLibro'])->name('homeLibro');

Route::get('/myreviews',[HomeReviewsController::class, 'index'])->name('myreviews');

Route::get('create', [HomeReviewsController::class, 'create'])->name('create'); //formulario
Route::post('store', [HomeReviewsController::class, 'store'])->name('store'); //sube archivo

Route::get('/showReview/{review}',[HomeReviewsController::class, 'showReview'])->name('showReview');

Route::delete('/delete/{id}',[HomeReviewsController::class,'delete'])->name('delete');
Route::get('edit/{review}',[HomeReviewsController::class, 'edit'])->name('edit');

Route::put('/update/{id}',[HomeReviewsController::class, 'update'])->name('update');

