@extends('reseñas.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <h1></h1>
    </div>
</div>
@endsection

@section('content2')
<section class="page-section bg-light" id="portfolio">
            <div class="container">
                <div class="row">
                    

                </div>
            </div>
        </section>
@endsection
