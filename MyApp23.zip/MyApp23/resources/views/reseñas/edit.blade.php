@extends('reseñas.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <h1></h1>
    </div>
</div>
@endsection

@section('content2')
<section class="page-section bg-light" id="portfolio">
            <div class="container">
                <form action="{{url('update/'. $review->id)}}" method="post" style:"position:absolute">
                    @csrf
                    @method('PUT')
                        <img style="height:500px" name="file" class="img-fluid" src="../storage/app/public/images/{{$review->images->file}}" alt="..." />
                        <div class="text-center divBtn" style="padding-top:20px">
                            <p class="textoBtn">Cambiar imagen</p>
                            <input type="file" name="file" id="file"/>
                        </div>
                        <div class="titulo" style="padding-top:20px">
                            <input value="<?php echo $review->titulo;?>" type="text" minlength="2" maxlength="100" class="form-control" name="titulo" placeholder="Titulo">
                        </div>
                        <div class="form-group" style="margin-top:20px">
                               <select class="form-control" name="tipo" id="tipo">
                                    <option value="<?php echo $review->tipo; ?>">{{$review->tipo}}</option>
                                    @foreach($tipos as $tip)
                                    <?php
                                        $tipo = $review->tipo;
                                    ?>
                                    @if($tip != $tipo)
                                    <option value="<?php echo $tip; ?>">{{$tip}}</option>
                                    @endif
                                    @endforeach
                              </select>
                        </div>
                        <hr>
                        <div class="contReview">
                            <textarea type="text" minlength="2" maxlength="100" class="form-control" name="contReview" placeholder="Contenido" style="height:200px">{{$review->contReview}}</textarea>
                        </div>
                        <div class="text-center" style="padding-top:20px">
                            <button class="btn btn-primary btn-xs text-uppercase" id="editButton" type="submit">Editar</button>
                        </div>
                    </form>
            </div>
        </section>
        
        <style>
            .btn-primary1{
                background-color:red;
                color:white;
            }
            p.texto{
            	text-align: center;
            	color:white;
            }
            div.divBtn{
            	position:absolute;
            	margin:50px;
            	padding:10px;
            	width:150px;
            	background-color:red;
            	-webkit-border-radius:5px;
            	color:white;
            	top:525px;
            	left:800px;
            	
        }
        input#file{
        	position:absolute;
        	top:0px;
        	left:0px;
        	right:0px;
        	bottom:0px;
        	width:100%;
        	height:100%;
        	opacity: 0;
        }
        
        </style>
@endsection
