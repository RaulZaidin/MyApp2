@extends('reseñas.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <h1>Crear Reseña</h1>
    </div>
</div>
@endsection

@section('content2')
<section class="page-section bg-light" id="portfolio">
            <div class="container">
                <div class="row">
                    <section class="page-section" id="contact">
            <div class="container">
                <form id="Form" action="store" enctype="multipart/form-data" method="post">
                    @csrf
                    <div class="row align-items-stretch mb-5">
                        <div class="col-md-6">
                            <div class="form-group">
                                <!-- Titulo input-->
                                <input class="form-control" id="titulo" name="titulo" type="text" placeholder="Titulo" required/>
                            </div>
                            <div class="form-group" style="margin-top:20px">
                               <select class="form-control" name="tipo" id="tipo">
                                    <option value="selecciona">Selecciona el tipo</option>
                                    <option value="musica">Musica</option>
                                    <option value="pelicula">Pelicula</option>
                                    <option value="libro">Libro</option>
                              </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group form-group-textarea mb-md-0">
                                <!-- Reseña input-->
                                <textarea style="height:95px" class="form-control" id="contReview" name="contReview" placeholder="Reseña"></textarea>
                            </div>
                        </div>
                        <div class="col-md-6" style="margin-top:20px">
                            <input type="file" name="file" id="file"/>
                        </div>
                    </div>
                    
                    <div class="text-center"><button class="btn btn-primary btn-xl text-uppercase" id="submitButton" type="submit">Crear Reseña</button></div>
                </form>
            </div>
        </section>

                </div>
            </div>
        </section>
@endsection
