@extends('reseñas.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <h1></h1>
    </div>
</div>
@endsection

@section('content2')
<section class="page-section bg-light" id="portfolio">
            <div class="container">
                <div class="row">
                    <img style="height:500px" class="img-fluid" src="../storage/app/public/images/{{$review->images->file}}" alt="..." />
                    <h1 style="padding-top:30px" class="portfolio-caption-heading">{{$review->titulo}}</h1>
                    <h3 class="portfolio-caption-subheading text-muted">{{$review->tipo}}</h3>
                    <hr>
                    <p>{{$review->contReview}}</p>
                    @if($review->idusuario == $id)
                    <div class="text-center">
                        <form style="display:inline-block" action="{{route('edit', $review)}}" method="get">
                            <button class="btn btn-primary btn-xs text-uppercase" id="editButton" type="submit">Editar</button>
                        </form>
                        <form style="display:inline-block" action="{{url('delete/'. $review->id)}}" method="post">
                            @csrf
                            @method('DELETE')
                            <button class="btn btn-primary btn-xs text-uppercase" id="deleteButton" type="submit">Borrar</button>
                        </form>
                    </div>
                    @else
                    <h5 class="portfolio-caption-subheading text-muted">{{$review->users->name}}</h5>
                    
                    @endif

                </div>
            </div>
        </section>
@endsection
