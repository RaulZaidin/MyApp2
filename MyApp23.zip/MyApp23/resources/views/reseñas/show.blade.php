@extends('reseñas.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <h1>Mis Reseñas</h1>
    </div>
</div>
@endsection

@section('content2')
<section class="page-section bg-light" id="portfolio">
            <div class="container">
                <div class="row">
                     @foreach($reviews as $review)
                    <?php
                        $idusuario = $review->idusuario;
                    ?>
                        @if(($id == $idusuario))
                    <div class="col-lg-4 col-sm-6 mb-4">
                        <!-- Portfolio item 1-->
                        <div class="portfolio-item">
                            <a class="portfolio-link" data-bs-toggle="modal" href="{{route('showReview', $review)}}">
                                <img class="img-fluid" src="storage/app/public/images/{{ $review->images->file }}" alt="..." />
                            </a>
                            <div class="portfolio-caption">
                                <div class="portfolio-caption-heading">{{$review->titulo}}</div>
                                <div class="portfolio-caption-subheading text-muted">{{$review->tipo}}</div>
                            </div>
                        </div>
                    </div>
                    @endif
                 @endforeach

                </div>
            </div>
        </section>
@endsection
