@extends('reseñas.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <h1>Bienvenido</h1>
    </div>
</div>
@endsection

@section('content2')
<section class="page-section bg-light" id="portfolio">
            <div class="container">
                <div class="text-center">
                    <h2 class="section-heading text-uppercase">Categorias</h2>
                    <h3 class="section-subheading text-muted">Elige el tipo de reviews que quieres ver</h3>
                </div>
                <div class="row">
                    <div class="col-lg-4 col-sm-6 mb-4">
                        <!-- Portfolio item 1-->
                        <div class="portfolio-item">
                            <a class="portfolio-link" data-bs-toggle="modal" href="homeMusica">
                               
                                <img class="img-fluid" src="assets/img/portfolio/spotify.jpg" alt="..." />
                            </a>
                            <div class="portfolio-caption">
                                <div class="portfolio-caption-heading">Música</div>
                                <div class="portfolio-caption-subheading text-muted">Canciones</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-sm-6 mb-4">
                        <!-- Portfolio item 2-->
                        <div class="portfolio-item">
                            <a class="portfolio-link" data-bs-toggle="modal" href="homePelicula">
                                <img class="img-fluid" src="assets/img/portfolio/pelicula.jpg" alt="..." />
                            </a>
                            <div class="portfolio-caption">
                                <div class="portfolio-caption-heading" style="padding-top:50px">Peliculas</div>
                                <div class="portfolio-caption-subheading text-muted"></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-sm-6 mb-4">
                        <!-- Portfolio item 3-->
                        <div class="portfolio-item">
                            <a class="portfolio-link" data-bs-toggle="modal" href="homeLibro">
                                <img class="img-fluid" src="assets/img/portfolio/libro.jpg" alt="..." />
                            </a>
                            <div class="portfolio-caption">
                                <div class="portfolio-caption-heading">Libros</div>
                                <div class="portfolio-caption-subheading text-muted"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
@endsection
