@extends('reseñas.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <h1>Bienvenido</h1>
    </div>
</div>
@endsection
@section('content2')
<div class="container">
    <div class="row justify-content-center">
        
    </div>
</div>

@endsection